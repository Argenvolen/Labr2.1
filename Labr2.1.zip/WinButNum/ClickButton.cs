﻿using System;
using System.Windows.Forms;
using System.Drawing;

namespace WinButNum
{
    class ClickButton : Button
    {
        private int mClicks;
        public int Clicks
        {
            get { return mClicks; }
        }
        public ClickButton()
        {
            mClicks = 0;
        }

        protected override void OnClick(EventArgs e)
        {
            mClicks++;
            base.OnClick(e);
            this.Invalidate();
        }
        protected override void OnPaint(PaintEventArgs pevent)
        {
            base.OnPaint(pevent);
            Size textSize = TextRenderer.MeasureText(Clicks.ToString(), this.Font);
            TextRenderer.DrawText(pevent.Graphics, Clicks.ToString(), this.Font, new Point(this.Width - textSize.Width - 3, this.Height - textSize.Height - 3), SystemColors.ControlText);
        }
    }
}
