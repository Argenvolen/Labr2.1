﻿namespace WinButNum
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            clickButton1 = new ClickButton();
            clickButton2 = new ClickButton();
            SuspendLayout();
            // 
            // clickButton1
            // 
            clickButton1.Location = new Point(71, 41);
            clickButton1.MaximumSize = new Size(100, 50);
            clickButton1.Name = "clickButton1";
            clickButton1.Size = new Size(100, 0);
            clickButton1.TabIndex = 0;
            clickButton1.Text = "clickButton1";
            clickButton1.UseVisualStyleBackColor = true;
            clickButton1.Click += clickButton1_Click;
            // 
            // clickButton2
            // 
            clickButton2.Location = new Point(170, 114);
            clickButton2.Name = "clickButton2";
            clickButton2.Size = new Size(233, 124);
            clickButton2.TabIndex = 1;
            clickButton2.Text = "clickButton2";
            clickButton2.UseVisualStyleBackColor = true;
            clickButton2.Click += clickButton2_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(9F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(621, 405);
            Controls.Add(clickButton2);
            Controls.Add(clickButton1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
        }

        #endregion

        private ClickButton clickButton1;
        private ClickButton clickButton2;
    }
}